import java.util.HashMap;
import java.util.Map;
import java.util.Random;

public class MarketData {
    private Map<String, Stock> stocks;
    private Random random;

    public MarketData() {
        stocks = new HashMap<>();
        random = new Random();
        initializeMarket();
    }

    private void initializeMarket() {
        stocks.put("AAPL", new Stock("AAPL", 150 + random.nextDouble() * 50));
        stocks.put("GOOGL", new Stock("GOOGL", 1000 + random.nextDouble() * 200));
        stocks.put("AMZN", new Stock("AMZN", 2000 + random.nextDouble() * 500));
    }

    public Stock getStock(String symbol) {
        return stocks.get(symbol);
    }

    public void updateStockPrices() {
        for (Stock stock : stocks.values()) {
            double change = (random.nextDouble() - 0.5) * 10; 
            stock.setPrice(Math.max(0, stock.getPrice() + change)); 
        }
    }
}