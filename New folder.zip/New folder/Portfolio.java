import java.util.HashMap;
import java.util.Map;

public class Portfolio {
    private Map<String, Integer> stocks;

    public Portfolio() {
        stocks = new HashMap<>();
    }

    public void buyStock(String symbol, int quantity) {
        stocks.put(symbol, stocks.getOrDefault(symbol, 0) + quantity);
    }

    public void sellStock(String symbol, int quantity) {
        if (stocks.containsKey(symbol) && stocks.get(symbol) >= quantity) {
            stocks.put(symbol, stocks.get(symbol) - quantity);
            if (stocks.get(symbol) == 0) {
                stocks.remove(symbol);
            }
        } else {
            System.out.println("Not enough stocks to sell.");
        }
    }

    public void printPortfolio() {
        System.out.println("Your Portfolio:");
        for (Map.Entry<String, Integer> entry : stocks.entrySet()) {
            System.out.println("Stock: " + entry.getKey() + ", Quantity: " + entry.getValue());
        }
    }
}