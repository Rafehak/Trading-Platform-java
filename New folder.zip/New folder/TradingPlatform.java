import java.util.Scanner;

public class TradingPlatform {
    public static void main(String[] args) {
        MarketData marketData = new MarketData();
        Portfolio portfolio = new Portfolio();
        Scanner scanner = new Scanner(System.in);

        while (true) {
            marketData.updateStockPrices(); // Simulate price changes
            System.out.println("Available Stocks:");

            System.out.println("Enter command (buy/sell/portfolio/exit):");
            String command = scanner.nextLine();

            if (command.equalsIgnoreCase("exit")) {
                break;
            } else if (command.equalsIgnoreCase("portfolio")) {
                portfolio.printPortfolio();
            } else {
                System.out.println("Enter stock symbol:");
                String symbol = scanner.nextLine();
                System.out.println("Enter quantity:");
                int quantity = Integer.parseInt(scanner.nextLine());

                if (command.equalsIgnoreCase("buy")) {
                    portfolio.buyStock(symbol, quantity);
                    System.out.println("Bought " + quantity + " shares of " + symbol);
                } else if (command.equalsIgnoreCase("sell")) {
                    portfolio.sellStock(symbol, quantity);
                    System.out.println("Sold " + quantity + " shares of " + symbol);
                } else {
                    System.out.println("Unknown command.");
                }
            }
        }

        scanner.close();
        System.out.println("Exiting the trading platform.");
    }
}